
def main():
    from optparse import OptionParser
    parser = OptionParser()
    parser.add_option("-i","--input")
    parser.add_option("-t","--type")

    (option,args) = parser.parse_args()
    fname = option.input
    ifile = open(fname,'r')
    ofile = open(fname+".out",'w')
    dstr =ifile.readline()
    nday=0

    if (option.type == '1'):  # parsing data from old file type
       while( dstr != ''):
        if (dstr.find('PAGE')>0):
         dstr = dstr.replace(':','')
         dstr = dstr.split()
         nday = (int(dstr[1]) - 1010)*2+1
         for i in range(8):
          raw = ifile.readline()
          raw = raw.split()
          for j in range(2,len(raw)):
            if ((i*16+j-5)>=1) and ((i*16+j-5)<=124):
              if (((i*16+j-5) > 90) or (i*16+j-5) <3) and (int(raw[j],16)==170):
                raw[j]='0'
              ofile.write('%s;%s;%s\n'%(nday,i*16+j-5,int(raw[j],16)))
              print(['Day',nday,'Time',i*16+j-5,'Data',int(raw[j],16)])
       # 2nd half
         nday =nday+1
         for i in range(8):
          raw = ifile.readline()
          raw = raw.split()
          for j in range(2,len(raw)):
            if ((i*16+j-5)>=1) and ((i*16+j-5)<=124):
              if (((i*16+j-5) > 90) or (i*16+j-5) <3) and (int(raw[j],16)==170):
                raw[j]='0'
              ofile.write('%s;%s;%s\n'%(nday,i*16+j-5,int(raw[j],16)))
              print(['Day',nday,'Time',i*16+j-5,'Data',int(raw[j],16)])
        dstr = ifile.readline()
    if (option.type == '2'):  # parsing data from new file type
       while( dstr != ''):
        if (dstr.find('PAGE')>0):
         dstr = dstr.replace(':','')
         dstr = dstr.split()
         nday = (int(dstr[1]) - 1500)
         ndata=1;
         for i in range(16):
          raw = ifile.readline()
          raw = raw.split()
          if (i == 0):
            nday = int(raw[2],16)+ int(raw[3],16)*256
            start_time = int(raw[4],16)+int(raw[5],16)*256
          for j in range(1,len(raw)/2):
            if ((i*16+j*2-5)>=2) and ((i*16+j*2-5)<=250):
              if (nday != 65535):
                ofile.write('%s;%s;%s\n'%(nday,ndata,int(raw[j*2],16)+int(raw[j*2+1],16)*256))
                print(['Day',nday,'Time',ndata,'Data',int(raw[j*2],16)+int(raw[j*2+1],16)*256])
              ndata = ndata+1
        dstr = ifile.readline()




    ifile.close()
    ofile.close()

if __name__ == '__main__':
    main()


