#include "main3.h"
#define DEBUG 1

int16 timer_counter = 0;
int16 run_time =0;
int16 east_intensity=0;
int16 west_intensity=0;
float sensor_gain_correction =2.00; // east sensor gain correction
                                       // increase this value will make sun position shift toward west
float east_west_ratio=1.00;
int16 ch1_current =0;
int16 ch2_current =0;
int1 data_ready =0;

int32 temp_east_intensity=0;
int32 temp_west_intensity=0;
int32 temp_ch1_current=0;
int32 temp_ch2_current=0;



typedef enum {morning,mid_day,evening,night,none} day_stat;

void move_east(long msec)
{
   output_d(0b00001010);
   output_d(0b00001001);   
   delay_ms(msec);
   output_d(0b00001010); 
}

void move_west(long msec)
{
   output_d(0b00001010);
   output_d(0b00000110);   
   delay_ms(msec);
   output_d(0b00001010); 
}

boolean check_valid_sensor_value(long s1, long s2)
{
   if ((s1>1 && s2>1) && (s1>50 || s2>50)) return true;
   return false;
}


#int_timer2
void timer2_int()
{
   restart_wdt();
   timer_counter++;
   if (timer_counter % 125 ==0) { // 
      run_time++;
      
      //******* read short-circuit current           
      set_adc_channel(0);
      delay_us(10);
      temp_ch1_current += read_adc();
      set_adc_channel(1);
      delay_us(10);
      temp_ch2_current += read_adc();      
      //******* read light intensity                
      temp_east_intensity += (get_timer0());
      temp_west_intensity += (get_timer1());
      set_timer0(0);// east_sensor
      set_timer1(0);// west_sensor      
      if (timer_counter ==1250) { // 10 second pass
         timer_counter =0;
         ch1_current = (int16) (temp_ch1_current/10);
         ch2_current = (int16) (temp_ch2_current/10);
         east_intensity = (int16) (temp_east_intensity/10);
         west_intensity = (int16) (temp_west_intensity/10);
         data_ready =1;
         
         temp_east_intensity=0;
         temp_west_intensity=0;
         temp_ch1_current=0;
         temp_ch2_current=0;
         
      }      
   }
}



void main()
{

   
   day_stat day_status=none;
   setup_adc_ports(AN0_AN1_AN3);
   setup_adc(ADC_CLOCK_INTERNAL);
   setup_psp(PSP_DISABLED);
   setup_spi(SPI_SS_DISABLED);
   setup_wdt(WDT_ON);
   setup_timer_0(RTCC_EXT_L_TO_H);
   setup_timer_1(T1_EXTERNAL|T1_DIV_BY_1);
   setup_timer_2(T2_DIV_BY_16,249,5); // overflow @ 125Hz
   setup_comparator(NC_NC_NC_NC);
   setup_vref(FALSE);
   set_timer0(0);// east_sensor
   set_timer1(0);// west_sensor 
   enable_interrupts(GLOBAL);
   enable_interrupts(INT_TIMER2);
//Setup_Oscillator parameter not selected from Intr Oscillator Config tab

   // TODO: USER CODE!!
   
   // try to figure out what part of day it is   
   printf("\r\n \r\n \r\n ********** TRACKING SYSTEM START ****** \r\n \r\n");

   if (DEBUG) printf("\r\n RUNTIME,I1,I2,EAST,WEST,RATIO,REMARK");
   
   while(1)
   {
      restart_wdt();

      
   
      if(data_ready) {
      //********** calculate east_west_ratio
      // east_west_ratio > 1.00 mean sun is toward the east side
      // east_west_ratio < 1.00 mean sun is toward the west side
      if (check_valid_sensor_value(east_intensity, west_intensity)) {
         //east_west_ratio = ( (float) east_intensity/ (float) west_intensity)*sensor_gain_correction;
         east_west_ratio = ((float) east_intensity*sensor_gain_correction) - (float) west_intensity;
         east_west_ratio = east_west_ratio *100.0 / (((float) east_intensity*sensor_gain_correction) + (float) west_intensity);
      } else
         east_west_ratio = 0.00;
      if (DEBUG) printf("\r\n%5ld,%4ld,%4ld,%5ld,%5ld,%5.3f,",run_time,ch1_current,ch2_current,east_intensity,west_intensity,east_west_ratio);
      //********** state table *************
      switch (day_status) {
      case (none):
            if (DEBUG) printf(" NONE" );
            if (check_valid_sensor_value(east_intensity, west_intensity)) { 
               move_east(45000); // go to east
               move_east(45000); // go to east            
               day_status = morning;
            } else { 
               day_status = night;
            }
            break;
      case  (morning):
            if (DEBUG) printf(" MORNING" );
            // in morning mode, panel is allow to move eastward until it meet the sun
            // sensor level also need to be high enogh, in direct sun light
            // after that it is allowed to move only in west direction
            if (check_valid_sensor_value(east_intensity, west_intensity) && (abs(east_west_ratio) < 3.00 ) \
            && ((east_intensity >500 || west_intensity> 500))) {
               day_status = mid_day;
            }
            if (east_intensity < 10 && west_intensity <10) {
               move_east(45000); // go to night position
               day_status =night;
            }            
            
            break;
      case (mid_day):
            if (DEBUG) printf(" MID_DAY" );      
            // in mid-day, panel only move toward west until dark
            if (east_intensity < 10 && west_intensity <10) {
               move_east(45000); // go to night position
               day_status =night;
            }
            break;
      case (night):
            if (DEBUG) printf(" NIGHT" );      
            // if only see some lights, morning has come
            if (check_valid_sensor_value(east_intensity, west_intensity)) {
               move_east(45000); // go to east
               move_east(45000); // go to east
               day_status =morning;
            }
            break;         
      } // end switch
      
      if (east_west_ratio > 3.00 && (day_status == morning)) {
         if (east_west_ratio > 15.00)
            move_east(1000);
         else
            move_east(300);           
         if (DEBUG) printf(" Move East");
      }
      if (east_west_ratio < -3.00  && (day_status == morning || day_status == mid_day)) {
         if (east_west_ratio < -15.00)
            move_west(1000);
         else
            move_west(300);           
         if (DEBUG) printf(" Move West");         
      }
      data_ready=0;      
   } //end if data_ready

   }

}
