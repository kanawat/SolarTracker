#include <18F458.h>
#device ADC=10
#include <stdlib.h>
//#include <math.h>

#fuses H4,NOWDT,NOPROTECT,NOLVP,PUT,NOLVP
#use fixed_io(d_outputs=PIN_D0, PIN_D1, PIN_D2, PIN_D3, PIN_D4, PIN_D5, PIN_D6, PIN_D7)
#use delay(clock=40000000)
#use rs232(baud=115200, xmit=PIN_C6, rcv=PIN_C7, BRGH1OK, parity =N,BITS=8)
#use spi(MASTER, DI=PIN_C4, DO=PIN_C5, CLK=PIN_C3, BITS=8, MSB_FIRST, IDLE=0)

#byte SSPSTAT = 0xFC7
#byte SSPCON1 = 0xFC6
#byte SSPCON2 = 0xFC5
#byte PIE1 = 0xF9D
#byte RCSTA= 0xFAB
#byte TXSTA= 0xFAC
#byte PIR1 = 0xF9E
#byte TMR1H = 0xFCF
#byte TMR1  = 0xFCE
#byte T1CON = 0xFCD

#define FLASH_CS PIN_C1
#define LED_FLASH	PIN_D0
#define LED_POWER	PIN_D1
#define LED_STAT	PIN_D2
#define MAX_IDLE 240

///////////////////////////////////////
// Data collection: 16 Hr/day (4am-8pm)
// 1 page of flash data = 512 byte will hold 4hr data, 240min. = 480 bytes
////////////////////////////////////////
// EEprom data
// start date
// stop  date
// current/total record length in days
//
/////////////////////////// flash_related_variable
int8 flash_mfg_id[4];
int8 flash_stat=0;
int8 flash_page_data=0;
int8 flash_page_data2=0;
///////////// DATA STORAGE ////////
#define ADDR_CAL_DATA    	0xf00000 // 8 bytes
#define ADDR_START_DATE		0xf00008 // 4 bytes
#define ADDR_LOG_LENGTH		0xf0000C // 2 bytes
#define ADDR_RATED_CURRENT	0xf0000E // 2 bytes

#define ADDR_MONTHLY_DATA 	0xf00010 // till 0xf000ff, each entry takes 4 bytes (2bytes for mon+yeear, bytes for page number)
#rom ADDR_CAL_DATA={0x0000,0x00000,0x0000,0x0000} // offset1,gain1,offset2,gain2
#rom ADDR_START_DATE ={0x0000,0x0000} // day+mon, year of start logging date
#rom ADDR_LOG_LENGTH = {0x0000} // page# of current recording
#rom ADDR_RATED_CURRENT ={5000}
CHAR CONST LOGO[] = {"\r\n Solar Radiation Data Logger (ver 1.0)\r\n Copyright (c) 2010 Chaiyo Solution Co., Ltd. \r\n"};
CHAR CONST MAIN_MENU[]={"\r\n(I) Initialize & format flash memory \r\n(C) Calibrate current sensors \r\n(P) Set rated current of solar panel\r\n(T) Set date & time \r\n(D) Report detailed monthly data \r\n(R) Report daily eff sun hour \r\n(F) Refresh screen"};
CHAR CONST ALT_MENU[]={"\r\n(L) Start logging  \r\n(A) Stop logging"};
int8 const days_in_month[]={31,28,31,30,31,30,31,31,30,31,30,31,31,28,31,30,31,30,31,31,30,31,30,31,31,28,31,30,31,30,31,31,30,31,30,31,31,29,31,30,31,30,31,31,30,31,30,31};
CHAR MONTH[]={"JANFEBMARAPRMAYJUNJULAUGSEPOCTNOVDEC "};
CHAR CONST INFO1[] ={"\r\nAquisition status:"}; // empty, started, stopped
CHAR CONST INFO2[] ={"\r\nLog start date:"};
CHAR CONST INFO3[] ={"\r\nLog duration:"}; // how may days have the data been aquired
CHAR CONST INFO4[] ={"\r\nSensor data:"}; 
CHAR CONST INFO4_2[] ={"\r\nSolar panel rated current:"}; 
CHAR CONST INFO5[] ={"\r\nSensor Reading:"}; 
CHAR CONST INFO6[] ={"\r\nCurrent time:"}; 
CHAR CONST RETURN_MSG[]={"\r\n<press any key to return>"};
CHAR CONST START_MSG[]={"\r\n<press any key to start>"};
CHAR CONST WARNING1[]={"\r\n Erased previously logged data? (y/n)"};
CHAR CONST WARNING2[]={"\r\n Overwrite previously saved data? (y/n)"};
CHAR CONST WARNING3[]={"\r\n Please set date & time first."};
/////////////////////////// timer_related
unsigned int32 timer_sec =0;
unsigned int32 nDay=1;
unsigned int8 user_dd=1;
unsigned int8 user_mm=1;
unsigned int16 user_yyyy=2010;
unsigned int8 int_mm=1;
unsigned int8 log_start_dd,log_start_mm;
unsigned int16 log_start_yyyy=2010;
unsigned int16 log_length=0; // duration of log in days
unsigned int16 idle_time=0;
////////////////////////// caibration data
int16 offset[2];
int16 gain[2];
int16 RATED_CURRENT =5000;

///////////////////////////sensor reading & logging//////////
unsigned int16 acc_data=0; //accumulate every 1 second 
unsigned int8 iMonth_logged=0;
/////////////////////////// flag
struct flag {
   boolean time_date_set;
   boolean logging_start;
   boolean led_stat1;
   boolean unused3;
   boolean unused4;
   boolean unused5;
   boolean unused6;
   boolean unused7;
} flag;

////////////////////////// test .. should be deleted later
int8 i=0b00010001;
int16 value1,value2,value3,month_menu_selection;
byte c,answer;

/////////////////////////////////////////////////////
void init_rs232() {
   bit_clear(PIR1,4);  //TXIF=0
   bit_clear(PIR1,5);  //RCIF=0
   bit_clear(PIE1,5);  //RCIE=0
   bit_clear(RCSTA,7); //SPEN=0
   bit_clear(RCSTA,4); //CREN=0
   bit_clear(TXSTA,4); //SYNC=0
   bit_clear(TXSTA,5); //TXEN=0 
   delay_cycles(10);
   bit_set(RCSTA,4); //CREN=1
   bit_set(RCSTA,7); //SPEN=1
   bit_set(TXSTA,5); //TXEN=1
   //bit_set(PIE1,5); //RCIE=1

}



void flash_read_mfg_id() {
		output_low(FLASH_CS);
		output_high(LED_FLASH);
		delay_cycles(20);
		spi_write(0x9F);
		flash_mfg_id[0] = spi_read(0);
		flash_mfg_id[1] = spi_read(0);
		flash_mfg_id[2] = spi_read(0);
		flash_mfg_id[3] = spi_read(0);
		delay_cycles(20);
		output_high(FLASH_CS);
		output_low(LED_FLASH);
}

void flash_read_stat() {
		output_low(FLASH_CS);
		output_high(LED_FLASH);
		delay_cycles(20);
		spi_write(0xD7);
		flash_stat = spi_read(0);
		delay_cycles(20);
		output_high(FLASH_CS);
		output_low(LED_FLASH);
}

void flash_wait_until_ready() {
   int16 wait_loop=0;
   for ( wait_loop=0; wait_loop<0x03FF; wait_loop++) {
	 flash_read_stat();
     if ((flash_stat & 0xAC)==0xAC) break;
	 delay_cycles(255);

   }
   if (wait_loop==0x03FF) printf("\r\n!");
}



// we dont' do this anymore, we will read tru buffer2
void flash_read_page(int16 pageAddress, int16 pageIndex) {

	//pageAddress <<= 1;
	//pageAddress &= 0xFE;
    if (flash_mfg_id[1]==0x26) pageAddress <<=1;
	flash_wait_until_ready();
   	output_low(FLASH_CS);
	output_high(LED_FLASH);
	delay_cycles(20);
   	spi_write(0xD2);
    spi_write(make8(pageAddress,1));
    spi_write(make8(pageAddress,0)|make8(PageIndex,1));
    spi_write(make8(pageIndex,0));
    spi_write(0);
    spi_write(0);
    spi_write(0);
    spi_write(0);
	flash_page_data = spi_read(0);
	flash_page_data2 = spi_read(0);
   	output_high(FLASH_CS);
	output_low(LED_FLASH);
}

void flash_block_erase() {
   int8 i,j;
   i=0xFF;
   do
   {
   i++;
   flash_wait_until_ready();
   output_low(FLASH_CS);
   output_high(LED_FLASH);
   spi_write(0x50);
   j = i>>5;
   spi_write(j);
   j = i<<3;
   spi_write(j);
   spi_write(0);
   output_high(FLASH_CS);
   output_low(LED_FLASH);

   } while(i!=0xFF);
   flash_wait_until_ready();
}

void flash_buffer_write(int8 ibuffer,int16 data, int16 PageIndex, int8 page_erase) {
   int16 i;
   flash_wait_until_ready();
   output_low(FLASH_CS);
   output_high(LED_FLASH);
   delay_cycles(20);
   if (ibuffer==1) 
		spi_write(0x84);
   else if (ibuffer==2) 
		spi_write(0x87);
   spi_write(0);
   spi_write(make8(PageIndex,1));
   spi_write(make8(PageIndex,0));
   if(page_erase!=1) {
   	spi_write(make8(data,0)); // writing LSB
   	spi_write(make8(data,1)); // writing MSB
   } else { 
	for (i=0;i<512;i++) spi_write(0);
   } 
   output_high(FLASH_CS);
   output_low(LED_FLASH);

}

void flash_buffer_read(int8 ibuffer,int16 PageIndex) {
   flash_wait_until_ready();
   output_low(FLASH_CS);
   output_high(LED_FLASH);
   delay_cycles(20);
   if (ibuffer==1) spi_write(0xD4); // use 0xD4 must have 1 dummy byte after address bytes
   else if (ibuffer==2) spi_write(0xD6);
   spi_write(0);
   spi_write(make8(PageIndex,1));
   spi_write(make8(PageIndex,0));
   spi_write(0); // dummy byte required
   flash_page_data = spi_read(0);
   flash_page_data2 = spi_read(0);
   output_high(FLASH_CS);   
   output_low(LED_FLASH);

}

void flash_set_256_page_size() {
   flash_wait_until_ready();
   output_low(FLASH_CS);
   output_high(LED_FLASH);
   delay_cycles(20);
   spi_write(0x3D);
   spi_write(0x2A);
   spi_write(0x80);
   spi_write(0xA6);
   output_high(FLASH_CS); 
   output_low(LED_FLASH);

}

void flash_write_buffer1_to_main_memory(int16 pageAddress) {
   if (flash_mfg_id[1]==0x26) pageAddress <<=1;
   flash_wait_until_ready();
   output_low(FLASH_CS);
   output_high(LED_FLASH);
   delay_cycles(20);	
   spi_write(0x83);
   spi_write(make8(pageAddress,1));
   spi_write(make8(pageAddress,0));
   spi_write(0);
   output_high(FLASH_CS);
   output_low(LED_FLASH);

}

/*
void flash_write_page(int16 pageAddress) {
   int8 i,check_sum;
   int16 counter;
   char input_data;
   disable_interrupts(GLOBAL);
   //output_high(FLASH_CS);
   flash_wait_until_ready();
   delay_cycles(50);
   output_low(FLASH_CS);
   if (pageAddress%2) spi_write(0x82); else spi_write(0x85);
   if (flash_mfg_id[1]==0x26) pageAddress <<=1;
   spi_write(make8(pageAddress,1));
   spi_write(make8(pageAddress,0));
   spi_write(0);
   check_sum=0;
   counter=0;
   check_sum=0xCC;
   for (counter=0;counter<512;counter++) {
      input_data = getc();
      check_sum ^= input_data;
      spi_write(input_data);
   }
   output_high(FLASH_CS);
   enable_interrupts(GLOBAL);
}
*/
void flash_read_main_memory_to_buffer(int8 ibuffer, int16 pageAddress) {
   flash_wait_until_ready();
   if (flash_mfg_id[1]==0x26) pageAddress <<=1;
   output_low(FLASH_CS);
   output_high(LED_FLASH);
   if (ibuffer==1) spi_write(0x53);
   else if(ibuffer==2) spi_write(0x55);
   spi_write(make8(pageAddress,1));
   spi_write(make8(pageAddress,0));
   spi_write(0);
   output_high(FLASH_CS);
   output_low(LED_FLASH);

}


void init_spi() {
	setup_spi(spi_master |spi_h_to_l );
    SSPSTAT = 0xC0;
}


void print_page_data(int8 type,int16 nPage) {
// filled output buffer with memory content in flash page memory
    int8 i;
    int16 j;
    for(i=0;i<32;i++) {
      printf("\r\n%02X : ",i);
      for (j=0;j<8;j++) {
		switch(type) {
			case 1: { flash_read_page(nPage,(int16) ((int16)i*16+j*2)); break;}
			case 2: { flash_buffer_read(1,(int16) ((int16)i*16+j*2)); break;}
			case 3: { flash_buffer_read(2,(int16) ((int16)i*16+j*2)); break;}
		}
		printf("%02X %02X ",flash_page_data,flash_page_data2);
	  }
   }
}

void print_date_time(int8 dd, int8 mm, int16 yyyy, int32 print_current_time)
{
// use ((year+2)%4)*12+mon to find days in month
    char mon[4];
	memcpy(mon,MONTH+3*(mm-1),3);
	mon[3]=0;
	if (dd!=0)
		printf("%02d-%s-%04ld",dd,mon,yyyy);
	else
		printf("%s-%04ld",mon,yyyy);

	if (print_current_time!=0) printf(" %02d:%02d:%02d"(int8) (print_current_time/3600), (int8) ((print_current_time%3600)/60),(int8) (print_current_time%60));
}

void prepare_flash_for_data(int16 npage,int16 dd, int16 mm, int16 yyyy,int16 ioffset,int16 igain) 
{
	int8 i;
// erase 4 pages of flash starting from page #npage and create header with date provided
	flash_buffer_write(1,0,0,1); //page erase buffer1
	flash_buffer_write(1,(dd<<8 | mm),0,0);
	flash_buffer_write(1,yyyy,2,0);
	flash_buffer_write(1,ioffset,4,0);
	flash_buffer_write(1,igain,6,0);

//flash_buffer_write(int8 ibuffer,int16 data, int16 PageIndex, int8 page_erase)
	for(i=0;i<4;i++) {
		flash_buffer_write(1,i,8,0); // page index
		flash_write_buffer1_to_main_memory(npage+(int16)(i));
	}
	flash_read_main_memory_to_buffer(1,nPage); // read the first page of the day into buffer1
}



//////////////////////////////////
#int_timer1
void timer1_ovf()
{   // overflow every 1 sec
      //set_timer1(get_timer1()+0x7FB8);
	  #asm
		MOVLW 0x03;
		MOVWF TMR1;
		MOVLW 0x80;
		MOVWF TMR1H;
	  #endasm
      //timer_sec+=1; 
	  timer_sec = timer_sec+1;
	  if (idle_time < MAX_IDLE+10) idle_time++;
      //timer_sec=86400;
	  if (flag.logging_start==1) flag.led_stat1 = !flag.led_stat1;
	  if (flag.led_stat1) output_high(LED_STAT); else output_low(LED_STAT);
	  int_mm= (((user_yyyy+2)%4)*12+(user_mm-1))%47+1;
      if (timer_sec>=86400) {
		user_dd++;
		if (user_dd > days_in_month[int_mm-1])  {
			user_mm++; 
			user_dd=1;
			if (flag.logging_start==1) iMonth_logged++;
		}
	    if (user_mm > 12) {
			user_mm=1; user_yyyy++;
		}
		if (flag.logging_start==1) {
			log_length++;
			prepare_flash_for_data((log_length-1)*4,user_dd,user_mm,user_yyyy,offset[0],gain[0]);
			write_eeprom((int8)ADDR_LOG_LENGTH,log_length); // save log length
			write_eeprom((int8)ADDR_LOG_LENGTH+1,log_length>>8); // save log length
			write_eeprom(((int8)ADDR_MONTHLY_DATA)+(iMonth_logged-1)*2,log_length);
			write_eeprom(((int8)ADDR_MONTHLY_DATA)+(iMonth_logged-1)*2+1,log_length>>8);

		}
	  }
	  timer_sec = timer_sec % 86400;

	  if ((timer_sec >= 14400) && (timer_sec <= 72000) && flag.logging_start==1) { // between time of 4am to 8pm
			if ((timer_sec%60)==0) {
				if (timer_sec>=14460) {
					flash_buffer_write(1,acc_data,0x10+(((timer_sec-14400-1)%14400)/60)*2,0);
				}
				acc_data=0;
			}
			acc_data+= read_adc(); // multuiply by 30 for accelerate time test
			if ((timer_sec%3600 ==0) && (timer_sec > 14400)) {
				flash_write_buffer1_to_main_memory(((timer_sec-14400-1)/14400)+(log_length-1)*4);
				flash_read_main_memory_to_buffer(1,((timer_sec-14400)/14400)+(log_length-1)*4);
			}
	  }

	  if ((flag.logging_start==1) && ((iMonth_logged>=120)||(log_length>=1024))) {
		flag.logging_start=0; // log is full;
		flag.led_stat1=1;
	  }  
}
void print_rep(char c, int8 nrep) 
{
	int8 i;
	for (i=0; i<nrep; i++) printf("%c",c);
}


void print_menu() {
	int16 current_read;
	//init_rs232();
	idle_time=0;
    print_rep('\n',36);
    printf("\r");
	print_rep('*',48);
    printf("%s",LOGO);
	print_rep('*',48);
    printf("%s",MAIN_MENU);
    printf("%s\r\n",ALT_MENU);
	print_rep('*',48);
	printf("\r\n    logger status and information\r\n");
	print_rep('*',48);

    printf("%s",INFO1);
	if (flag.logging_start==0) printf(" Stopped"); else printf(" Started"); 
    printf("%s",INFO2);
	if (log_start_yyyy ==0) printf(" N/A"); else print_date_time(log_start_dd,log_start_mm,log_start_yyyy,0);
    printf("%s",INFO3);
	printf(" %ld days",log_length);
    printf("%s",INFO4);
	printf(" Offset=%4ld DAC; Gain=%5.2f mA/DAC",offset[0]/60,(float)(gain[0])/256.0);
    printf("%s",INFO4_2);
	printf("%ld mA",RATED_CURRENT);
    printf("%s",INFO5);
	current_read=read_adc()+read_adc()+read_adc()+read_adc();
	current_read=current_read>>2;
	if (current_read*60 > offset[0])
		printf(" %5.2f mA",((float)(current_read*60-offset[0]))/60.0*(float)(gain[0])/256.0);
	else printf(" 0.00 mA");
    printf("%s",INFO6);
	if (flag.time_date_set) print_date_time(user_dd,user_mm,user_yyyy,timer_sec); else printf(" Not set");
    printf("\r\n");
	print_rep('*',48);
}

void read_saved_data() {
   int16 temp_mem;
   int8 i;
   temp_mem= offset;
   for (i=0;i<4;i++) memset(temp_mem+i,read_eeprom(ADDR_CAL_DATA+i),1);
   temp_mem= gain;
   for (i=0;i<4;i++) memset(temp_mem+i,read_eeprom(ADDR_CAL_DATA+i+4),1);
   memset(&log_start_dd,read_eeprom(ADDR_START_DATE),1);
   memset(&log_start_mm,read_eeprom(ADDR_START_DATE+1),1);
   temp_mem=&log_start_yyyy;
   for (i=0;i<2;i++) memset(temp_mem+i,read_eeprom(ADDR_START_DATE+2+i),1);
   temp_mem=&log_length;
   for (i=0;i<2;i++) memset(temp_mem+i,read_eeprom(ADDR_LOG_LENGTH+i),1);
   temp_mem=&RATED_CURRENT;
   for (i=0;i<2;i++) memset(temp_mem+i,read_eeprom(ADDR_RATED_CURRENT+i),1);

}

void init_eeprom() {
   int8 i;
   for (i=0;i<4;i++) write_eeprom((int8)ADDR_START_DATE+i,0x00);
   for (i=0;i<2;i++) write_eeprom((int8)ADDR_LOG_LENGTH+i,0x00);
   for (i=0;i<0xF0;i++) write_eeprom((int8)ADDR_MONTHLY_DATA+i,0x00);
}


void calibrate_sensor() {
	char answer;
	unsigned int16 value1,value2;
	unsigned int8 i;
	set_adc_channel(0);
	printf("\r\n Please set current = 0.00 A, then press any key:\r\n"); 
	while(!kbhit()) printf("\rSensor Offset=%4ld",read_adc());
	getch();
	value1=0;
	for (i=0;i<60;i++) value1+= read_adc();
	
	printf("\r\n Please set current = 2.00 A, then press any key:\r\n"); 
	while(!kbhit()) 
	{
		printf("\rSensor Gain=%4.2f mA/DAC [%4ld]          ", 2000.0*60.0/((float)(read_adc()*60.0-value1)),read_adc());	
		delay_ms(20);
	}
	getch();
	value2=0;
	for (i=0;i<60;i++) value2+= read_adc();
	idle_time=0;
	printf("\r\n Save calibration data? (y/n)");
	do { 
		answer='N';
		while(!kbhit() && idle_time < MAX_IDLE);
		if (idle_time>=MAX_IDLE) break;
		answer=getch();
	}while(answer!='Y' && answer!='N' && answer!='y' && answer!='n');
	if (answer == 'Y' || answer =='y') {
		offset[0]=value1;
		gain[0]= (int16)((2000.0*256.0*60.0/((float)(value2-value1))));
		for (i=0;i<2;i++) write_eeprom(ADDR_CAL_DATA+i,offset[0]>>(i*8));
		for (i=0;i<2;i++) write_eeprom(ADDR_CAL_DATA+i+4,gain[0]>>(i*8));
	}

}

int16 get_number_from_terminal() {
	char c[8];
	int8 i;
	i=0;
	idle_time=0;
	do {
		while(!kbhit() && idle_time < MAX_IDLE);
		if (idle_time>=MAX_IDLE) return 0;
		c[i]=getc();
		if (c[i]==8) { 
			if (i>0) {
				i--;
				printf("%c %c",0x08,0x08);
			}
		}
		else if (isdigit(c[i])) {printf("%c",c[i]); i++;}
	} while( (c[i] != 13) && (i<6) );
	c[i]=0; // null terminated
	return atol(c);
}

int16 print_monthly_menu() 
{
	unsigned int16 temp_mem;
	unsigned int16 selection=0;
	unsigned int8  local_month_index=0;
	unsigned int16 local_month_end_page=0;
	if (log_length==0)
	{
		printf("\r\n!! No recorded data !! ");
		printf("%s",RETURN_MSG);
		getc();
		return 0;
	}
	do {
	local_month_index=0;
	local_month_end_page=0;
    print_rep('\n',48);
    printf("\r");
	print_rep('*',48);
    printf("\r\nMonthly data report menu \r\n");
	print_rep('*',48);
	printf("\r\n [ 0] Return to main menu");
	do {
   		temp_mem=&local_month_end_page;
   		for (i=0;i<2;i++) memset(temp_mem+i,read_eeprom(ADDR_MONTHLY_DATA+(local_month_index*2)),1);
		if (local_month_end_page ==0) break;
		if (local_month_index%3==0) printf("\r\n");
		printf(" [%2d] ",local_month_index+1);
		print_date_time(0,(log_start_mm+local_month_index-1)%12+1,log_start_yyyy+(log_start_mm+local_month_index-1)/12,0);
		printf("    ");
		local_month_index++;
	} while(local_month_index<120);
	printf("\r\n");
	print_rep('*',48);
	printf("\r\nSelect month to report: ");
	selection=get_number_from_terminal();
	} while(selection > (local_month_index+1));
	return selection;
}

void print_daily_detail(int16 nDay) {
	int8 i;
	int16 j;
	int8 local_dd, local_mm;
	int16 local_yyyy;
	int16 local_offset;
	int16 local_gain;
	int8 local_page_no;
	int16 local_data;
	float temp;
	float temp2=0.0;

	if (nDay>1024) {
		printf("\r\n !! Data Error !!");
		return;
	}
	for(i=0;i<4;i++) {
		flash_read_main_memory_to_buffer(2,nDay*4+i);
		flash_buffer_read(2,0); // get day, month
		local_dd = flash_page_data2;
		local_mm = flash_page_data;
		flash_buffer_read(2,2); // get year
		local_yyyy = ((int16)flash_page_data2)<<8 | flash_page_data;
		flash_buffer_read(2,4); // offset
		local_offset = ((int16)flash_page_data2)<<8 | flash_page_data;
		flash_buffer_read(2,6); // gain
		local_gain = ((int16)flash_page_data2)<<8 | flash_page_data;	
		flash_buffer_read(2,8); // page_no
		local_page_no = flash_page_data;
		for(j=0;j<240;j++) {
			flash_buffer_read(2,0x10+j*2); // data
			local_data = ((int16)flash_page_data2)<<8 | flash_page_data;
			printf("\r\n");
			disable_interrupts(global);
			print_date_time(local_dd,local_mm,local_yyyy,14400+((int32)local_page_no)*14400+((int32)j)*60);
			enable_interrupts(global);
			temp=((float)(local_data-local_offset))*((float)local_gain)/256.0/60000.0;
			disable_interrupts(global);
			if (local_data>local_offset) {printf(";%5.3f",temp); temp2=temp2+temp;}
			else printf(";%5.3f",0.0);
			enable_interrupts(global);
			
		}
	}
}

void print_monthly_data(int8 user_selection)
{
	unsigned int16 start_page,end_page;
	unsigned int16 temp_mem;
	int16 iPage;
	if (user_selection==1) start_page = 0;
	else {
		temp_mem=&start_page;
		for (i=0;i<2;i++) memset(temp_mem+i,read_eeprom(ADDR_MONTHLY_DATA+((user_selection-2)*2)+i),1);
	}
	temp_mem=&end_page;
	for (i=0;i<2;i++) memset(temp_mem+i,read_eeprom(ADDR_MONTHLY_DATA+((user_selection-1)*2)+i),1);

	printf("\r\n%s",START_MSG);
	getc();
	printf("\r\n DATE_TIME; CURRENT(A)");		


	
	for (iPage=start_page;iPage<end_page;iPage++) 
	{
		print_daily_detail(iPage);
	}
}

void print_daily_summary(int16 nDay)
{
	int8 i;
	int16 j;
	int8 local_dd, local_mm;
	int16 local_yyyy;
	int16 local_offset;
	int16 local_gain;
	int8 local_page_no;
	int16 local_data;
	int32 current_summary=0;
	float effective_current=0.0;
	if (nDay>1024) {
		printf("\r\n !! Data Error !!");
		return;
	}		
	for(i=0;i<4;i++) {
		flash_read_main_memory_to_buffer(2,nDay*4+i);
		flash_buffer_read(2,0); // get day, month
		local_dd = flash_page_data2;
		local_mm = flash_page_data;
		flash_buffer_read(2,2); // get year
		local_yyyy = ((int16)flash_page_data2)<<8 | flash_page_data;
		flash_buffer_read(2,4); // offset
		local_offset = ((int16)flash_page_data2)<<8 | flash_page_data;
		flash_buffer_read(2,6); // gain
		local_gain = ((int16)flash_page_data2)<<8 | flash_page_data;	
		flash_buffer_read(2,8); // page_no
		local_page_no = flash_page_data;
		for(j=0;j<240;j++) {
			flash_buffer_read(2,0x10+j*2); // data
			local_data = ((int16)flash_page_data2)<<8 | flash_page_data;
			if ((local_data !=0) && (local_data > local_offset)) 
				current_summary= current_summary + (int32)(local_data)- (int32)(local_offset);
		}
	}
	// after getting sum of all current in the day
	effective_current= (float) (current_summary) * ((float) (local_gain))/256.0;
	effective_current=effective_current/((float)RATED_CURRENT)/3600.0;	
	printf("\r\n");
	disable_interrupts(global);
	print_date_time(local_dd,local_mm,local_yyyy,0);
	printf("; %5.3f",effective_current);
	enable_interrupts(global);
}

void print_all_data()
{
	int16 iPage;
	for (iPage=0;iPage<log_length;iPage++) 
	{
		print_daily_summary(iPage);
	}	
}


void main() {
	int8 i;
    setup_adc_ports(AN0);
    setup_adc(ADC_CLOCK_INTERNAL);
	setup_adc_ports(AN0_AN1_VSS_VREF);
    set_adc_channel(0);
	set_tris_a(0xFF);
    set_tris_c(0b10010101);
	delay_cycles(300);
	init_spi();
	flag.time_date_set=0;
	flag.logging_start=0;
	flash_wait_until_ready();
	flash_read_mfg_id();
	flash_read_stat(); // stat & 0xBF == 0x9C means device ready
	if (flash_mfg_id[1]!=0x26) 
	{	printf("\r\nFlash error\r\n");
		return;
	}
    T1CON = 0b00000111;  // 0b10011011
    //enable_interrupts(INT_RDA);
    enable_interrupts(INT_TIMER1);   // Setup interrupt on falling edge
    enable_interrupts(GLOBAL);
	output_high(LED_POWER);
	flag.led_stat1=1;
	read_saved_data();
    print_menu();
    init_rs232();
	while(1) {
		if (bit_test(RCSTA,1)==1) init_rs232();
		c=getc();
		switch(c) {
			case 'I': {
				idle_time=0;
				printf("%s",WARNING1);
				do { 
					answer='N';
					while(!kbhit() && idle_time < MAX_IDLE);
					if (idle_time>=MAX_IDLE) break;
					answer=getch();
				}while(answer!='Y' && answer!='N' && answer!='y' && answer!='n');
				if (answer == 'Y' || answer =='y')	init_eeprom();
				read_saved_data();
				print_menu();   
				break;}
			case 'C': {
				calibrate_sensor();
				read_saved_data();
				print_menu();   
				break;}
			case 'T': {
				printf("\r\nSet date time in [DD-MM-YYYY HH:MIN:SEC] format");
				printf("\r\n[DD]:");
 				user_dd=get_number_from_terminal();
				printf("\r\n[MM]:");
 				user_mm=(get_number_from_terminal()-1)%12+1;
				printf("\r\n[YYYY]:");
 				user_yyyy=get_number_from_terminal();
				printf("\r\n[HH]:");
				value1=(get_number_from_terminal()%24);
				printf("\r\n[MIN]:");
				value2=(get_number_from_terminal()%60);
				printf("\r\n[SS]:");
				value3=(get_number_from_terminal()%60);
				timer_sec=3600*((int32)value1)+60*((int32)value2)+((int32)value3);
				flag.time_date_set =1;
				print_menu();   
				break;}	
			case 'F': {
			    print_menu();
				break;
				}	
			case 'L': {
			// prepare page#0 and erase buffer1 prepare for writing
				if (flag.time_date_set==0) {
					printf("%s",WARNING3);
					printf("%s",RETURN_MSG);
					getc();
					print_menu();
					break;
				} 
				if (flag.logging_start==1) break;
				printf("%s",WARNING2);
				do { 
					answer='N';
					while(!kbhit() && idle_time < MAX_IDLE);
					if (idle_time>=MAX_IDLE) break;
					answer=getch();
				}while(answer!='Y' && answer!='N' && answer!='y' && answer!='n');
				if (answer == 'N' || answer =='n') { print_menu(); break;}
				init_eeprom();
				read_saved_data();
				prepare_flash_for_data(0,user_dd, user_mm, user_yyyy,offset[0],gain[0]);
				if ((timer_sec >=14400) && (timer_sec <=72000)) 
					flash_read_main_memory_to_buffer(1,((timer_sec-14400)/14400));
			//  save log starting time
				log_start_dd=user_dd;
				log_start_mm=user_mm;
				log_start_yyyy=user_yyyy;
			// write log starting time to eeprom
				write_eeprom((int8)ADDR_START_DATE,log_start_dd);
				write_eeprom((int8)ADDR_START_DATE+1,log_start_mm);
			    for (i=0;i<2;i++) write_eeprom((int8)ADDR_START_DATE+2+i,log_start_yyyy>>(i*8));
			// enable logging
				flash_wait_until_ready();
				log_length=1;
				iMonth_logged=1; // monthly index
				write_eeprom((int8)ADDR_LOG_LENGTH,log_length);
				write_eeprom(((int8)ADDR_MONTHLY_DATA)+(iMonth_logged-1)*2,log_length);
				write_eeprom(((int8)ADDR_MONTHLY_DATA)+(iMonth_logged-1)*2+1,log_length>>8);
				delay_cycles(512);
				read_saved_data();
				flash_wait_until_ready();
				flag.logging_start=1;
				print_menu();
				break;}
			case 'A': {
				if (flag.logging_start==1) {
				idle_time=0;
				printf("\r\n Stop logging data? (y/n)");
				do { 
					answer='N';
					while(!kbhit() && idle_time < MAX_IDLE);
					if (idle_time>=MAX_IDLE) break;
					answer=getch();
				}while(answer!='Y' && answer!='N' && answer!='y' && answer!='n');
				if (answer == 'Y' || answer =='y') {
					flag.logging_start=0;
					flag.led_stat1=1;
					// save last page data
					if ((timer_sec > 14400) && (timer_sec <= 72000))
						flash_write_buffer1_to_main_memory(((timer_sec-14400-1)/14400)+(log_length-1)*4);
					flash_wait_until_ready();
				}
				}
				print_menu();
				break;}
			case 'D': {
				// save last page data
				if ((timer_sec > 14400) && (timer_sec <= 72000) && flag.logging_start==1)
					flash_write_buffer1_to_main_memory(((timer_sec-14400-1)/14400)+(log_length-1)*4);
				flash_wait_until_ready();
				do {
					month_menu_selection=print_monthly_menu();
					if (month_menu_selection==0) {print_menu(); break;}
					print_monthly_data(month_menu_selection);
					printf("%s",RETURN_MSG);
					getc();
				} while(month_menu_selection!=0);
				print_menu();	
				break;}

			case 'R': {
				// save last page data
				if ((timer_sec > 14400) && (timer_sec <= 72000) && flag.logging_start==1)
					flash_write_buffer1_to_main_memory(((timer_sec-14400-1)/14400)+(log_length-1)*4);
				flash_wait_until_ready();

				printf("\r\n%s",START_MSG);
				getc();
				printf("\r\nDATE_TIME; EFF_SUN_HOUR");		
				print_all_data();
				printf("%s",RETURN_MSG);
				getc();
				print_menu();	
				break;}
			case 'P': {
				printf("\r\n Please enter solar panel rated current (mA):");
				value1 = get_number_from_terminal();
				if (value1 !=0) RATED_CURRENT = value1;
				write_eeprom((int8)ADDR_RATED_CURRENT,RATED_CURRENT);
				write_eeprom((int8)ADDR_RATED_CURRENT+1,RATED_CURRENT>>8);
				print_menu();	
			}
/*
			case 'z': { 
				//flash_read_main_memory_to_buffer(2, 0);
				print_page_data(2,1); break;}
			case 'x': { 
				for (value1=0;value1<(log_length*4);value1++) {
					printf("\r\nPAGE:%ld\r\n",value1);
					print_page_data(1,value1); 
				}
				break;}
			case 'q': {
				print_daily_detail(0);
				break;}
			case 'w': {
				prepare_flash_for_data(0,user_dd, user_mm, user_yyyy,offset[0],gain[0]);
				for (value1=0;value1<(4);value1++) {
					printf("\r\nPAGE:%ld\r\n",value1);
					print_page_data(1,value1); 
				}
				for (value1=180;value1<190;value1++)
					prepare_flash_for_data(value1*4,user_dd+value1, user_mm, user_yyyy,offset[0],gain[0]);
				for (value1=0;value1<(4);value1++) {
					printf("\r\nPAGE:%ld\r\n",value1);
					print_page_data(1,value1); 
				}

				break;}			 
*/

		}	
	}


}