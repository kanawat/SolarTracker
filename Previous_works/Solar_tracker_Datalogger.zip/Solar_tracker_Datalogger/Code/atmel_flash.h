#include <18F458.h>
#device ADC=10
#include <stdlib.h>





void flash_read_mfg_id() {
		output_low(FLASH_CS);
		delay_cycles(20);
		spi_write(0x9F);
		flash_mfg_id[0] = spi_read(0);
		flash_mfg_id[1] = spi_read(0);
		flash_mfg_id[2] = spi_read(0);
		flash_mfg_id[3] = spi_read(0);
		delay_cycles(20);
		output_high(FLASH_CS);
}

void flash_read_stat() {
		output_low(FLASH_CS);
		delay_cycles(20);
		spi_write(0xD7);
		flash_stat = spi_read(0);
		delay_cycles(20);
		output_high(FLASH_CS);
}

void flash_wait_until_ready() {
   int8 wait_loop=0;
   for ( wait_loop=0; wait_loop<0xFF; wait_loop++) {
	 flash_read_stat();
     if ((flash_stat & 0xBF)==0x9C) break;
	 delay_cycles(100);
   }
}

void flash_read_page(int16 pageAddress, int16 pageIndex) {

	//pageAddress <<= 1;
	//pageAddress &= 0xFE;
    if (flash_mfg_id[1]==0x26) pageAddress <<=1;
	flash_wait_until_ready();
   	output_low(FLASH_CS);
	delay_cycles(20);
   	spi_write(0xD2);
    spi_write(make8(pageAddress,1));
    spi_write(make8(pageAddress,0)|make8(PageIndex,1));
    spi_write(make8(pageIndex,0));
    spi_write(0);
    spi_write(0);
    spi_write(0);
    spi_write(0);
	flash_page_data = spi_read(0);
	flash_page_data2 = spi_read(0);
   	output_high(FLASH_CS);
}

void flash_block_erase() {
   int8 i,j;
   i=0xFF;
   do
   {
   i++;
   flash_wait_until_ready();
   output_low(FLASH_CS);
   spi_write(0x50);
   j = i>>5;
   spi_write(j);
   j = i<<3;
   spi_write(j);
   spi_write(0);
   output_high(FLASH_CS);
   } while(i!=0xFF);
   flash_wait_until_ready();
}

void flash_buffer1_write(int16 data, int16 PageIndex, int8 nData) {
   int i;
   flash_wait_until_ready();
   output_low(FLASH_CS);
   delay_cycles(20);
   spi_write(0x84);
   spi_write(0);
   spi_write(make8(PageIndex,1));
   spi_write(make8(PageIndex,0));
   spi_write(make8(data,0)); // writing LSB
   spi_write(make8(data,1)); // writing MSB
   output_high(FLASH_CS);
}

void flash_buffer1_read(int16 PageIndex) {
   int i;
   flash_wait_until_ready();
   output_low(FLASH_CS);
   delay_cycles(20);
   spi_write(0xD4); // use 0xD4 must have 1 dummy byte after address bytes
   spi_write(0);
   spi_write(make8(PageIndex,1));
   spi_write(make8(PageIndex,0));
   spi_write(0); // dummy byte required
   flash_page_data = spi_read(0);
   flash_page_data2 = spi_read(0);
   output_high(FLASH_CS);   
}

void flash_set_256_page_size() {
   flash_wait_until_ready();
   output_low(FLASH_CS);
   delay_cycles(20);
   spi_write(0x3D);
   spi_write(0x2A);
   spi_write(0x80);
   spi_write(0xA6);
   output_high(FLASH_CS); 
}

void flash_write_buffer1_to_main_memory(int16 pageAddress) {
   if (flash_mfg_id[1]==0x26) pageAddress <<=1;
   flash_wait_until_ready();
   output_low(FLASH_CS);
   delay_cycles(20);	
   spi_write(0x83);
   spi_write(make8(pageAddress,1));
   spi_write(make8(pageAddress,0));
   spi_write(0);
   output_high(FLASH_CS);
}

void flash_write_page(int16 pageAddress) {
   int8 i,check_sum;
   int16 counter;
   char input_data;
   disable_interrupts(GLOBAL);
   //output_high(FLASH_CS);
   flash_wait_until_ready();
   delay_cycles(50);
   output_low(FLASH_CS);
   if (pageAddress%2) spi_write(0x82); else spi_write(0x85);
   if (flash_mfg_id[1]==0x26) pageAddress <<=1;
   spi_write(make8(pageAddress,1));
   spi_write(make8(pageAddress,0));
   spi_write(0);
   check_sum=0;
   counter=0;
   check_sum=0xCC;
   for (counter=0;counter<512;counter++) {
      input_data = getc();
      check_sum ^= input_data;
      spi_write(input_data);
   }
   output_high(FLASH_CS);
   enable_interrupts(GLOBAL);
}

void flash_read_main_memory_to_buffer1(int16 pageAddress) {
   flash_wait_until_ready();
   if (flash_mfg_id[1]==0x26) pageAddress <<=1;
   output_low(FLASH_CS);
   spi_write(0x53);
   spi_write(make8(pageAddress,1));
   spi_write(make8(pageAddress,0));
   spi_write(0);
   output_high(FLASH_CS);
}
